let firstNameLudwig
let lastNameBeethoven
let hireDateLudwig
let addressLudwig
let payRateLudwig


let firstNameJohann
let lastNameBach
let hireDateJohann
let addressJohann 
let payRateJohann


let firstNameWolfgang
let lastNameMozart
let hireDateWolfgang
let addressWolfgang
let payRateWolfgang



